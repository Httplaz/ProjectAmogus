#pragma once
#include <map>
#include <glm/glm.hpp>
#include "TextureAtlas.hpp"

class Assets
{
public:
private:
	TextureAtlas atlas;
};