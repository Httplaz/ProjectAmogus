#pragma once
#include "System.hpp"
#include "DefaultComponents.hpp"
#include "Camera.hpp"
#include "InstanceRenderer.hpp"

class InputSystem : public System<const MovementInputComponent, BodyComponent>
{
public:
	InputSystem(entt::registry& registry, glm::vec3& input) :
		input(input), System(registry) {}
	virtual void Process(registryView view)
	{
		entt::basic_registry registry;
		//auto clientInputView = registry.view<const MovementInputComponent, ClientInputComponent>();
		//auto randomInputView = registry.view<const MovementInputComponent, RandomInputComponent>();
		for (auto entity : view) {
			//glm::vec2 inputSum{ 0.f, 0.f };
			if (registry.try_get<ClientInputComponent>(entity))
			//{

			//}
			//auto randomInput = registry.try_get<RandomInputComponent>(entity);
			/*if (clientInput)
			{
				inputSum += glm::vec2{input.x, input.y};
			}
			if (randomInput)
			{
				inputSum += glm::vec2{random.next<float>(-1.f,1.f), random.next<float>(-1.f,1.f) };
			}*/
		}
	}
private:
	glm::vec3& input;
	SVRandom random;
};

class PhysicsSystem : public System<BodyComponent>
{
public:
	PhysicsSystem(entt::registry& registry, b2World& world) :
		world(world), System(registry) {}
	virtual void Process(registryView view)
	{
		float timeStep = 1.0f / 60.0f;
		int32 velocityIterations = 6;
		int32 positionIterations = 2;
		world.Step(timeStep, velocityIterations, positionIterations);
	}
private:
	b2World& world;
};

class RenderingSystem : public System<const BodyComponent, DrawableComponent>
{
public:
	RenderingSystem(entt::registry& registry, InstanceRenderer& renderer, Camera& camera) :
		renderer(renderer), camera(camera), System(registry){}
	virtual void Process(registryView view)
	{
		for (auto entity : view) {
			const auto& body = view.get<BodyComponent>(entity);
			auto& drawable = view.get<DrawableComponent>(entity);
			auto& inst = renderer.accessInstance(drawable.instanceId);
			inst.rotation = body.body->GetTransform().q.GetAngle();
			const b2Vec2 pos = body.body->GetTransform().p;
			inst.pos = glm::vec3(pos.x, pos.y, 0.f);
		}

		renderer.shader.use();
		renderer.shader.setMat4("cameraMatrix", camera.getMatrix());
		renderer.shader.setMat4("projectionMatrix", camera.getProjection());
		renderer.Draw();
	}
private:
	InstanceRenderer& renderer;
	Camera& camera;
};