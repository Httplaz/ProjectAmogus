#pragma once
#include <entt.hpp>
#include "DefaultComponents.hpp"

template<typename... Profile>
class System
{
protected:
	// Create a dummy instance of entt::registry to use decltype on the view method
    static entt::registry dummy_registry;

    // Use the template keyword to indicate that view is a template
    using registryView = decltype(dummy_registry.template view<Profile...>());
public:
	System(entt::registry& registry) : registry(registry){}
	virtual void Process(registryView view) = 0;
	void Run()
	{
		auto registryView = registry.view<Profile...>();
		Process(registryView);
	}
protected:
	entt::registry& registry;
};