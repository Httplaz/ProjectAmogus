#pragma once
#include <glm/glm.hpp>
#include <Box2D/Box2D.h>
struct DrawableComponent
{
	uint16_t instanceId;
};

struct BodyComponent
{
	b2Body* body;
};

struct CameraTargetComponent
{

};

struct MovementInputComponent
{
};

struct RandomInputComponent
{

};

struct ClientInputComponent
{
};