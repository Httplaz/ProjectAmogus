// �������� ����������
#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include "imgui.h"
#include "imgui_impl_opengl3.h"
#include "imgui_impl_glfw.h"

#include <entt.hpp>
#include <Box2D/Box2D.h>

#include <glm/gtx/vector_angle.hpp>
// ��������������� ����������
#include <iostream>
#include <thread>
#include <chrono>

#include "SVRandom.hpp"

#include "Shader.hpp"
#include "WorldView.hpp"
#include "InstanceRenderer.hpp"
#include "Camera.hpp"
#include "World.hpp"
#include "DefaultSystems.hpp"

Camera camera;

void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mode);
glm::vec3 clientInput;
glm::vec2 cursorPos;

bool firstMouse;
void cursor_position_callback(GLFWwindow* window, double xpos, double ypos)
{
	if (firstMouse)
	{
		cursorPos.x = xpos;
		cursorPos.y = ypos;
		firstMouse = false;
	}

	float xoffset = xpos - cursorPos.x;
	float yoffset = cursorPos.y - ypos; // reversed since y-coordinates go from bottom to top

	cursorPos.x = xpos;
	cursorPos.y = ypos;
}

void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
	const float zoomSpeed = 0.04f; // �������� ���������������

	camera.scale(1.0f + zoomSpeed * yoffset);
}

namespace stats
{
	float averageFps = 0.f;
	float actualFps = 0.f;
}

static int scrWidth, scrHeight;

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	scrWidth = width;
	scrHeight = height;
	glViewport(0, 0, width, height);
	float aspectRatio = static_cast<float>(width) / height;
	float left = -aspectRatio;
	float right = aspectRatio;
	float bottom = -1.0f;
	float top = 1.0f;
	float near = -1.0f;
	float far = 1.0f;

	// ������� ������������� ������� ��������
	glm::mat4 projection = glm::ortho(left, right, bottom, top, near, far);

	camera.setProjection(projection);
}


// ���������� ������ GLFW
void glfw_error_callback(int error, const char* description) {
	std::cerr << "GLFW Error: " << description << std::endl;
}

// ������������� GLFW � GLAD
GLFWwindow* init() {
	glfwSetErrorCallback(glfw_error_callback);
	if (!glfwInit()) {
		std::cerr << "Failed to initialize GLFW" << std::endl;
		return nullptr;
	}

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 5);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// ������� ����
	scrWidth = 800;
	scrHeight = 600;
	GLFWwindow* window = glfwCreateWindow(800, 600, "OpenGL Mint Rectangle", nullptr, nullptr);
	if (!window) {
		std::cerr << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return nullptr;
	}

	glfwMakeContextCurrent(window);

	// �������������� GLAD
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
		std::cerr << "Failed to initialize GLAD" << std::endl;
		return nullptr;
	}
	glfwSwapInterval(1); // Enable vsync
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetKeyCallback(window, keyCallback);
	glfwSetCursorPosCallback(window, cursor_position_callback);
	glfwSetScrollCallback(window, scroll_callback);

	// Initialize ImGui
	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO();
	(void)io;
	ImGui::StyleColorsDark();
	io.FontGlobalScale = 2.0f;
	ImGui_ImplGlfw_InitForOpenGL(window, true);
	ImGui_ImplOpenGL3_Init("#version 410");

	return window;
}

void renderGui()
{
	// Start the ImGui frame
	ImGui_ImplOpenGL3_NewFrame();
	ImGui_ImplGlfw_NewFrame();
	ImGui::NewFrame();

	ImGui::Begin("STATS", nullptr);
	ImGui::Text((std::string("fps: ") + std::to_string(stats::averageFps)).c_str());
	ImGui::End();

	ImGui::Render();
	ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

// ������� �������
int main() {
	GLFWwindow* window = init();
	if (!window) return -1;

	Shader shader("default.vert", "default.frag");

	SVRandom random;
	entt::registry registry;

	// Initialize the Box2D world
	b2Vec2 gravity(0.0f, 0.0f); // Define the gravity vector
	b2World physWorld(gravity);

	//Rectangle rectangle;
	InstanceRenderer renderer(1, 1024, 4096);
	auto meshIndex = renderer.addMesh({
		// positions   // texCoords
		InstanceRenderer::Vertex{glm::vec4{ 0.5f,  0.5f,  1.0f, 1.0f}}, // top right
		InstanceRenderer::Vertex{glm::vec4{0.5f, -0.5f,  1.0f, 0.0f} }, // bottom right
		InstanceRenderer::Vertex{glm::vec4{-0.5f,  0.5f,  0.0f, 1.0f }}, // bottom left
		InstanceRenderer::Vertex{glm::vec4{ -0.5f, -0.5f,  0.0f, 0.0f}}  // top left
		});

	int playerEntity = random.next<int>(1024);

	for (int i = 0; i < 1024; i++) {
		auto instanceId = renderer.addInstance(meshIndex, {
			{random.next<float>(100.f), // x position
		random.next<float>(100.f), i/4096.f }, // y position
		random.next<float>(0.5f, 2.f), // scale
			random.next<float>(50.f), //rotation
			static_cast<uint32_t>(i)%16});

		const auto entity = registry.create();
		registry.emplace<DrawableComponent>(entity, instanceId);

		auto& instance = renderer.accessInstance(instanceId);

		// Define the body type and position
		b2BodyDef bodyDef;
		bodyDef.type = b2_dynamicBody; // or b2_staticBody if it doesn't move
		bodyDef.position.Set(instance.pos.x, instance.pos.y);

		// Create the body in the world
		auto& body = registry.emplace<BodyComponent>(entity, physWorld.CreateBody(&bodyDef));

		// Define the shape and fixture
		b2PolygonShape box;
		box.SetAsBox(instance.scale / 2.0f, instance.scale / 2.0f); // half-width, half-height

		b2FixtureDef fixtureDef;
		fixtureDef.shape = &box;
		fixtureDef.density = 1.0f;
		fixtureDef.friction = 0.9f;
		//fixtureDef.isSensor = true;

		// Add the fixture to the body
		body.body->CreateFixture(&fixtureDef);

		registry.emplace<MovementInputComponent>(entity);

		if (i == playerEntity)
		{
			registry.emplace<CameraTargetComponent>(entity);
			registry.emplace<ClientInputComponent>(entity);
		}
		else
		{
			registry.emplace<RandomInputComponent>(entity);
		}
	}

	RenderingSystem renderingSystem(registry, renderer, camera);
	PhysicsSystem physSystem(registry, physWorld);
	InputSystem inputSystem(registry, clientInput);

	World world;
	world.st();

	WorldGenerator::init();

	WorldGenerator::setImpl(std::unique_ptr<ColorsGenerator>(new ColorsGenerator));

	WorldView worldView(world);

	Chunk a;
	std::fill(a.tiles, a.tiles + WorldParams::chunkSize * WorldParams::chunkSize, uint32_t(-1));
	worldView.setDefaultChunk(a);


	for (auto i = 0; i < WorldParams::gpuChunkMapSide; i++)
		for (auto j = 0; j < WorldParams::gpuChunkMapSide; j++)
			world.loadChunk({ j,i });
	// ���� ���������
	double lastTime = glfwGetTime(), currentTime;
	double targetFPS = 60.f;
	double targetFrameTime = 1.0 / targetFPS;

	while (!glfwWindowShouldClose(window)) {
		auto bodyView = registry.view<BodyComponent>();

		// use forward iterators and get only the components of interest
		for (auto entity : bodyView) {
			auto& body = bodyView.get<BodyComponent>(entity);
			body.body->ApplyLinearImpulseToCenter(b2Vec2(random.next<float>(-0.02f, 0.02f), random.next<float>(-0.02f, 0.02f)), true);
		}

		const float cameraSpeed = 0.05f / camera.scale1; // �������� ����������� ������

		auto clientInputView = registry.view<BodyComponent, ClientInputComponent>();
		for (auto entity : clientInputView) {
			auto& body = clientInputView.get<BodyComponent>(entity);
			float maxDimension = std::max(scrWidth, scrHeight);
			body.body->ApplyLinearImpulseToCenter(b2Vec2(clientInput.x*cameraSpeed, clientInput.y*cameraSpeed), true);
			glm::vec2 cursorPosLocal = glm::normalize((cursorPos / glm::vec2(scrWidth, scrHeight) - glm::vec2(0.5f)) * maxDimension/glm::vec2(scrHeight, scrWidth));
			float angle = glm::orientedAngle(glm::vec2(1.f, 0.f), cursorPosLocal);
			body.body->SetTransform(body.body->GetTransform().p, glm::pi<float>()*2.f-angle);
		}

		auto cameraTargetView = registry.view<const BodyComponent, CameraTargetComponent>();
		for (auto entity : clientInputView) {
			const auto& body = cameraTargetView.get<const BodyComponent>(entity);
			camera.setTranslation({ body.body->GetTransform().p.x,body.body->GetTransform().p.y });
		}




		// ������ ���� ������� ������ (������ ����)
		glClearColor(0.6f, 1.0f, 0.6f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);

		worldView.setViewMatrix(glm::inverse(glm::translate(camera.getMatrix(), glm::vec3(glm::vec2(2.), 0.))));


		worldView.update();
		worldView.render();
		//pool.render();

	
		inputSystem.Run();
		renderingSystem.Run();
		physSystem.Run();
		//worldView.update();
		renderer.Draw();

		renderGui();

		// ��������� ������ � �������
		glfwSwapBuffers(window);
		glfwPollEvents();

		const float zoomSpeed = 0.04f; // �������� ���������������

		camera.scale(1.0f + zoomSpeed * clientInput.z);
		//camera.scale(1.0f - zoomSpeed * clientInput.z;

		// ���������� FPS
		currentTime = glfwGetTime();
		double frameTime = currentTime - lastTime;
		while (frameTime < targetFrameTime) {
			// ���� �� ���������� ���� ������� ������, ������� ���������� �����
			currentTime = glfwGetTime();
			frameTime = currentTime - lastTime;
		}
		stats::averageFps = 1.f / frameTime;
		lastTime = glfwGetTime();
	}



	// ������� ��� ������� GLFW ����� �������
	glfwTerminate();
	return 0;
}

void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
	//std::cout << origin1.z << "\n\n\n\n\n";
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GL_TRUE);

	if (action == GLFW_PRESS)
	{
		if (key == GLFW_KEY_W)
			clientInput.y++;
		if (key == GLFW_KEY_A)
			clientInput.x--;
		if (key == GLFW_KEY_S)
			clientInput.y--;
		if (key == GLFW_KEY_D)
			clientInput.x++;
		if (key == GLFW_KEY_Q)
			clientInput.z++;
		if (key == GLFW_KEY_E)
			clientInput.z--;
	}

	if (action == GLFW_RELEASE)
	{
		if (key == GLFW_KEY_W)
			clientInput.y--;
		if (key == GLFW_KEY_A)
			clientInput.x++;
		if (key == GLFW_KEY_S)
			clientInput.y++;
		if (key == GLFW_KEY_D)
			clientInput.x--;
		if (key == GLFW_KEY_Q)
			clientInput.z--;
		if (key == GLFW_KEY_E)
			clientInput.z++;
	}
}
